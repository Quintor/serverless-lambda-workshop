# Replace the function definitions by the correct implementation.
class Rectangle:
    def __init__(self, x, y):
        pass

    def area(self):
        pass

    def describe(self):
        return f'This ...x... rectangle has an area of ...'


first = Rectangle(3, 5)
second = Rectangle(2, 1)
third = Rectangle(4, 3)

for r in [first, second, third]:
    print(r.describe())

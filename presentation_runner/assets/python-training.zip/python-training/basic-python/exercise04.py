# Define your functions here


def name_benefits_of_functions():
    for benefit in list_benefits():
        print(build_sentence(benefit))


name_benefits_of_functions()
